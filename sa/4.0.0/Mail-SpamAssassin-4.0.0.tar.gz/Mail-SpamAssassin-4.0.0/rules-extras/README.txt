Rules in this directory are NOT processed by masschecks or sa-update
Use at your own risk.

